	BLACK LOTUS SECRET MESSAGER V1.2	
    	 (c) 1999 Black Lotus Software

LEGAL NOTICE : Only user with direct permission from the author are allowed to acquire and use this software.  Amy knowledge of unlawfull use will result in criminal prosecution.


TABLE OF CONTENTS:

 1. INTRODUCTION
 2. HOW TO INSTALL
 3. HOW TO USE
 4. CONTACT BLACK LOTUS SOFTWARE


1. INTRODUCTION

 Secret Messager is a utility you can use to create and open encrypted text messages.  It featrues a simple text editor where you would type a message you want to encrypt, then you save the file.  Your message is converted to a format which is virtually impossible to decrypt.  Send the encrypted file to someone important and they can open and view the file with this software.


2. HOW TO INSTALL

 Open the .ZIP file with Winzip or similar unzip program.  There will be four install files.:
	- REAME.TXT -- This file.
	- SETUP.EXE -- The executable you run to install.
	- BLSECMESS.CAB -- A compressed file containing the program.
	-SETUP.1ST -- A setup file.
 Double-click the SETUP.EXE file and the install wizard will run.  To uninstall the program, open your Control Panel, then Add/Remove Programs.  Select Black Lotus Secret Messager and click Add/Remove.


4. CONTACT BLACK LOTUS SOFTWARE

 Check out all the other free and shareware software avialiable from Black Lotus Software at www.angelfire.com/wa/blacklotus.  Let us know what you think of this preliminary version of the software, blotusmail@aol.com.





	


