#include "stdio.h"
#include "conio.h"
#include "stdlib.h"
#include "dos.h"
#include "ctype.h"
#include "setjmp.h"

mindfuck()
{
char prompt[80];
clrscr();
gotoxy(1,2);
for(;;) {
printf("C:\\>");
scanf("%s",&prompt);
printf("\nIncorrect Dos Version");
printf("\n");
}}
main()
{
mindfuck();
}