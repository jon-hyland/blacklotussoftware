/*	HELLO.C -- Hello, world */

#include <stdio.h>

main()
{
	printf("Hello, world\n");
}



	