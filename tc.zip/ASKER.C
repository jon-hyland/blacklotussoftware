
main()
{
	char	name[150];

	printf("What's your name?\n");
	scanf("%s",name);
	printf("Hello, %s\n",name);
}