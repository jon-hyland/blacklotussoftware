#include "stdio.h"
#include "conio.h"
#include "stdlib.h"
#include "dos.h"
#include "ctype.h"
#include "setjmp.h"
#include "dir.h"

makedir()
{
mkdir("C:\01ab");
}
main()
{
makedir();
}