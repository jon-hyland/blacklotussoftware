#include <stdio.h>

main()
{
printf(" Call the millennium BBS\n");
printf("9:30pm to 7:00am\n");
}