/* This is a continuation of the project example on pages 29-30 */

char ss [] = "The restaurant at the end of";

char *GetString(void)
{
return ss;
}