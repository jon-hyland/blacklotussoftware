#include "math.h"
#include "stdio.h"
#include "window.h"

void series_solve(void);

series_solve(float answer)
{
long float t1,tn,answer,n;

window(10,);
gotoxy(10,20);
textcolor
