--== Random Desktop Utility v1.0. ==--
    (c) 1998 Black Lotus Software
        All rights reserved.

This utility will enable you to enjoy a different desktop image
every time you restart Windows.  You must follow the steps below
in order to get it to work properly.

1. Create the folder "C:\DESKBMP".  You must be specific.

2. Install the executable "RANDDESK.EXE" to this folder.

3. Copy all desktop images you wish included, to this
   folder. Files must be in BMP format.

4. Execute RANDDESK once to create "CURRENT.BMP".

5. From within Windows, set your desktop image to "C:\DESKBMP\CURRENT.BMP".
   One of your pictures should now be displayed on the desktop.

6. Add the following line to your AUTOEXEC.BAT file :
   C:\DESKBMP\RANDDESK.EXE

7. Restart your computer.

Note :  Since this program is strictly random, it is possible to view
        the same file more than once in a row.
