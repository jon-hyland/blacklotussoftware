                            NOTES FOR WORMBOMB V1.3

 Remember the old game Nibbles that came with Microsoft Basic in good
 old MS-DOS?  Well, this is Nibbles on steroids.  Wormbomb is a game
 where a little yellow worm crawls around the screen picking up tokens.
 Pick up all the tokens and advance to the next level.  As the worm
 crawls along, it will drop little bomb-turds.  Don't hit one of these
 unless you want to see your worm blown to smitherines.  Also don't touch
 the electric fry walls.  As you advance levels your worm will grow in
 length and speed.  This version also includes a high score list, which
 can be reset by deleting the high score file.

 Should you run into any problems with this game, try reinstalling it
 on C: drive.  I wrote this game a long time ago and there might be
 a few minor errors like that.  Another note : This program is intended
 to be run in FULL SCREEN DOS mode.  If running from Windows 95-98, press
 the Full Screen button on the top of the window (it has four red arrows).

 LEGAL NOTICE : This program is freeware and can be distributed freely.
 The Pascal source code is included.  Feel free to modify it in any way,
 but don't try and claim any credit, for you will be found and crushed
 by powerful forces beyond your understanding.

 Wormbomb v1.3 -- (c)1996  by Jon Hyland  and  Black Lotus Software
                        All rights reserved.
