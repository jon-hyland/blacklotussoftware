CRAZY 8'S -- README FILE

This is the first full program I wrote in Pascal. I was trying to teach myself a programming language with nothing but the Borland Turbo Pascal software help menu for instruction.  Without having access to a single book or manual I had to learn everything by trial and error.  The coding in this game is far from perfect, but keep in mind I was still fifteen when it was finished.  The game should work just fine but was ment to be run in FULL SCREEN DOS mode (not the Windows dialog box).  If you encounter any unexpected errors, try installing the game on C: drive.  No help file is included to teach you the card game.  I didn't feel like writing one, sorry folks.

This game is freeware and can be distributed freely.  The Pascal source code is included for you to see.  Modifications can be made as long as no credit of any kind is taken for this work.

Crazy 8's -- (c)1994 by Jon Hyland -- All rights reserved.  
