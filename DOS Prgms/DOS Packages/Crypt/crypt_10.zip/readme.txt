                             NOTES FOR CRYPT V1.0

 Crypt is a DOS command line utility that will take a text file and encrypt it making the document impossible to see or decode.  Decrypt will return an encrypted file to its normal state.  Compare is included to compare two text file to be sure they are exactly the same.  Text Crypt and Decrypt feature optional password protection for encrypted files.  Type FILENAME.EXE for command line parameters.

 All three files are freeware and can be distributed freely.  The source code is not available for anything here for obvious reasons.  Please make no modifications of any kind to any of this material.

 Crypt, Decrypt, and Comapre are copyright 1996 by Jon Hyland.  All rights reserved.
